#!/bin/bash
while [ 1 ] ; do
	mplayer $1
 sleep 1
done