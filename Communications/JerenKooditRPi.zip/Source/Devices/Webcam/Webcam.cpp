#include "Webcam.hh"
#include <string>

using namespace std;

Webcam::Webcam(){}

Webcam::~Webcam(){}

bool Webcam::init()
{

}

bool Webcam::setOn()
{

}

bool Webcam::setOff()
{
	// streami kiinni
}

bool Webcam::isOn()
{
	// streami pystyyn
}

string Webcam::getIP()
{
	// streamin osoite
}