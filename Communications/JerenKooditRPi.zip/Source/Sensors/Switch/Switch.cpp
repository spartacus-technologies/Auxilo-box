#include "Switch.hh"
#include "../sensor.hh"
#include "wiringPi/wiringPi.h"

//DEBUG
#include <iostream>

#define TEST_SWITCH_PIN 1

string sensorWasLastSeenOn = "";

Switch::Switch()
{

}

Switch::~Switch()
{
    
}

static void interruptHandler()
{
    //Energenie control
    Plugs* socket;
    socket = new Plugs();
    socket->socketOn("1");
    delete socket;
}


//Starts new thread for interrupt handling:
bool Switch::init()
{	  
	wiringPiSetup();
	wiringPiISR(TEST_SWITCH_PIN, INT_EDGE_RISING, &interruptHandler);
}

//This does not really do anything as interrupts are handled in own thread:
Sensor::sensorData Switch::getData() const
{
    sensorData returnValue;

    returnValue.sensorID = "motion_detector";
    returnValue.isSuccessful = true;
    returnValue.read_time = sensorWasLastSeenOn;
    returnValue.value = 1;

	return returnValue;
}
