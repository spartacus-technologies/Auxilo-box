#ifndef SWITCH_HH
#define SWITCH_HH

#include "../sensor.hh"
#include "../../Devices/Plugs/Plugs.hh"

class Switch: public Sensor
{
public:
    Switch();
    ~Switch();

    virtual bool init();
    virtual sensorData getData() const;
	
	private:
	//Pointers to necessary Hardware:
	//...
};

#endif // SWITCH_HH
