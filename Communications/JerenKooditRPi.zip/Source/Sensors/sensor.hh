#ifndef SENSOR_HH
#define SENSOR_HH

#include <unistd.h>
#include <string>

// Interface for sensors

using namespace std;

class Sensor
{
	
public:
	
	//TODO: this struct as return value for getData():
	struct sensorData{
	
		double value;
		bool isSuccessful;
		string sensorID;
		string read_time;
	};
	
	virtual bool init() = 0;
	virtual sensorData getData() const = 0;

protected: 

private:
	
};

#endif // SENSOR_HH
