#!/bin/bash

# test if ran with sudo
if [ $USER != "root" ]; then
	echo "Please run this script as root. Aborting..."
	exit 1
fi

vlcinstalled=$(apt-cache policy vlc | grep "none")
energinstalled=$(apt-cache policy sispmctl | grep "none")

# vlc or library for controlling energenie is not installed
if [[ -n "$vlcinstalled" || -n "$energinstalled" ]]; then

	# check if connected to internet
	echo "Checking internet connection..."
	connection=$(((ping -W 5 -c3 google.com) > /dev/null 2>&1) && echo "up" || (exit 1 && echo "down" ))
	if [ "$connection" != "up" ]; then
		echo "Please connect to internet. Aborting..."
		exit 1
	fi
	
	# sispmctl is used for energenie
	if [[ -n "$energinstalled" ]]; then
		echo "Installing sispmctl for energenie..."
		apt-get install sispmctl
	fi

	# install vlc. Vlc is needed for sounds
	if [[ -n "$vlcinstalled" ]]; then
		echo "Installing vlc..."
		apt-get install vlc
	fi
	
fi


# Make scripts executable
echo "Making scripts executable"
chmod u+x Sensors/Thermometer/Thermometer.pl
chmod u+x Devices/Speaker/repeat.sh
chmod u+x Devices/Speaker/stop.sh

# load necessary kernel modules in boot and now
echo "Load kernel modules w1-gpio, w1-therm"
echo “w1-gpio” >> /etc/modules
echo “w1-therm” >> /etc/modules
modprobe w1-gpio && modprobe w1-therm

echo "Making software"
make

exit 0
