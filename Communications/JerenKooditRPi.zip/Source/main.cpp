//RaspberryPi -softa
// Eetu & Vesa

#include <iostream>
#include <vector>
#include <unistd.h>

#include "Sensors/sensor.hh"
#include "Sensors/Switch/Switch.hh"
#include "Sensors/Thermometer/Thermometer.hh"
#include "Sensors/Humidity/Humidity.hh"

#include "Communications/Communications.hh"
#include "Communications/protocol.pb.h"

#include "Devices/Plugs/Plugs.hh"
#include "Devices/Voice/voice.hh"
#include "Devices/Speaker/Speaker.hh"
#include "Devices/NexaPlugs/NexaPlugs.hh"

using namespace std;

bool initSensors(vector<Sensor*>*);
bool initDevices();

//NexaPlug* Nplug;

int main()
{	
	
	//for debug:
	//initDevices();


	// //Objects:
	// Communications serverconnection;
	// serverconnection.initConnection();
    Communications network_;
    network_.initiate();

	vector<Sensor*> sensors; 
	
	initSensors(&sensors);
	
	// //Energenie control
	// Plugs* socket;
	// socket = new Plugs();

	// //Motion detector control
	// Switch* motion_detector;
	// motion_detector = new Switch();
	// motion_detector->init();
	
	//main -loop:
	while(1){
	
		//cout << "loop..." << endl;
			
		//Read Values:
			
		//Test:
		for(unsigned i = 0; i < sensors.size(); ++i){
			
			Sensor::sensorData data = sensors.at(i)->getData();
			
			//Debug:
			cout<<"Sensor -ID: "<<data.sensorID<<endl;
			cout<<"Read OK: "<<data.isSuccessful<<endl;
			cout<<"Value: "<<data.value<<endl;
			cout<<"Time: "<<data.read_time<<endl;
			
			DataMessage mesg;
			mesg.set_devicename("Eetun boksi");
			mesg.mutable_datamesg()->set_hardwareid(data.sensorID);
			mesg.mutable_datamesg()->set_data(data.value);
			mesg.mutable_datamesg()->set_timestamp(data.read_time);
			network_.sendMessage(mesg);
			cout<<"Message sent."<<endl;

            DataMessage rcvMsg;
            // Check for received messages.
            if(network_.getMessage(rcvMsg))
            {
                // Message received
                cout << "Message received: data, " << rcvMsg.mutable_datamesg()->data()
                     << ", " << rcvMsg.mutable_datamesg()->timestamp() << ", " <<
                     rcvMsg.mutable_datamesg()->hardwareid() << endl;
            }
            else
            {
                // No messages received, carry on....
            }
		}
		/*
		cout<<"Nexa: "<<endl;
		int state = 0;
		cin>>state;
		*/
        //Send data to server:
        // Make protobuf message
        /*
        DataMessage mesg;
        mesg.set_devicename("box1");
        mesg.mutable_datamesg()->set_hardwareid("hardID");
        mesg.mutable_datamesg()->set_timestamp("12-12-12,12:12:12");
        //network_.sendMessage();
        */

		//Sleep some time or wait for server trigger:
        sleep(2);

	// 	// socket->socketOff("1");
	// 	// sleep(2);
	// 	// socket->socketOn("1");
	}

	cout<<"main(): return"<<endl;
	return 0;
}

bool initDevices(){

	//Speaker & Voice:
	
	Speaker* speaker = new Speaker();
	Voice* voice = new Voice();
	voice->addNewCommand(Voice::SPEAKER_PLAY, "soita");
	Voice::VoiceCommand cmd = voice->newVoiceCommand();
	delete voice;

	if(cmd == Voice::SPEAKER_PLAY)
	{
		speaker->playSound(false, "Resources/Sounds/NukeAlarm.mp3");
	}
	else
	{
		speaker->playSound();
	}

	delete speaker;
	//cout<<"Anna Nexalle ID: ";
	
	//int id;
	//cin>>id;
    //Nplug = new NexaPlug(id);
	
	return true;
}

//function initializes all sensors and adds them to vector:
bool initSensors(vector<Sensor*>* sensors){
	
	Sensor* sensorPtr;
	
	//Thermometers:
	sensorPtr = new Thermometer();
	
	//Create new Thermoeters in loop until all have been assigned to objects.
	//Also, last object must be deleted since it has no hardware and thus is useless:
	while(sensorPtr->init()){
		
		//init OK -> append to vector:
		sensors->push_back(sensorPtr);
		//new sensor is created for next loop:
		sensorPtr = new Thermometer();
	}
	
	//latest Thermometer init was a failure -> delete object:
	delete sensorPtr;
	
	//Humidity sensor(s):
	/*
	sensorPtr = new Humidity();
	
	//This cannot fail: (as far as I know...)
	sensorPtr->init();
	
	sensors->push_back(sensorPtr);
	*/
	
	//Some other sensor:
	//sensorPtr = new Switch();
	//...
	
		
	//Debug:
	cout<<"initSensors(): SensorVector size: "<<sensors->size()<<endl;
	
	//all went well:
	return true;
}
